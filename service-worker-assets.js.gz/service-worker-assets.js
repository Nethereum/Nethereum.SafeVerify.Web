self.assetsManifest = {
  "version": "OsIyEDV7",
  "assets": [
    {
      "hash": "sha256-47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU=",
      "url": ".nojekyll"
    },
    {
      "hash": "sha256-Ps2EqpQtAHIfcMzWG8A9KuCME6yn86porJbKiOVBYYc=",
      "url": "404.html"
    },
    {
      "hash": "sha256-zHgRTxmkXQsSVm7V32O+gxWM2ZHnwQ3emBLJALUM92U=",
      "url": "Nethereum.GnosisValidator.styles.css"
    },
    {
      "hash": "sha256-NgHobvE5wu6MFuX0QImF1lk8IP4UUN3UDirKa0WQVYc=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-TOPYwKltorv5iM1JqqzJayZWZx7LFnfSq2AhkWFNwrg=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-eKXQfzXa/kJKzNEah3/x5PbQ7B6iGhuKCRHNlb5q+S8=",
      "url": "_content/Nethereum.Blazor/Nethereum.Blazor.gezp6wesy7.bundle.scp.css"
    },
    {
      "hash": "sha256-Lxqq+qiqGwXreFFnEkOZ00jEH/z2xH57vOZ9qeaBmwA=",
      "url": "_content/Nethereum.Blazor/NethereumEIP6963.js"
    },
    {
      "hash": "sha256-mJeVuwkRQbU/TYh6HEcVQG4nK7jcWLiSagvbIEcRGhg=",
      "url": "_framework/ADRaffy.ENSNormalize.wa9ywt4h2t.wasm"
    },
    {
      "hash": "sha256-gy0YVyBWlVPAW/D2WdBB/hMOkSFk7t4D1p0xyiKNrcs=",
      "url": "_framework/BouncyCastle.Cryptography.lawgjmc8sm.wasm"
    },
    {
      "hash": "sha256-Se/4Kw/K7zPusKeV8Nl0XyP1/SMKoWVNrZVgrWL2kjI=",
      "url": "_framework/FluentValidation.rrdop3141f.wasm"
    },
    {
      "hash": "sha256-/lGmebPvAOERloWb4kB6LJdjVdLjF71fUwNgu0VAi2I=",
      "url": "_framework/Microsoft.AspNetCore.Authorization.miumi3x3d4.wasm"
    },
    {
      "hash": "sha256-HJqt7YYU5nra4lbju+nm781vNiJ85vdBE/sp7H81PiE=",
      "url": "_framework/Microsoft.AspNetCore.Components.Authorization.k8r8iu26gn.wasm"
    },
    {
      "hash": "sha256-Ux573peKEQ218Cy5jfERh3g4RoecVRs/uW6c5DeBAu4=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.lmcfcyebxn.wasm"
    },
    {
      "hash": "sha256-UMKuMN3hFIRfCZHEez4IdEUU+PNukdrMGeWuvWrJXPQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.gw4qjd2zm5.wasm"
    },
    {
      "hash": "sha256-flGCF5ZOjcqmURIU2Y4ntmf/y8vp32FnKfQkB/JFpY8=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.ed2mpgo6c2.wasm"
    },
    {
      "hash": "sha256-9OXk+xnLAsGuw0obXy2Kw/LVMtlkJoRrHMxdsZXKE5U=",
      "url": "_framework/Microsoft.AspNetCore.Components.ol0cwnfnkz.wasm"
    },
    {
      "hash": "sha256-5X/2Yb6a8AQ4OWI/WbQVZ3vYngHQsZAi6zQSBS95t3s=",
      "url": "_framework/Microsoft.AspNetCore.Metadata.tqaa7drzg6.wasm"
    },
    {
      "hash": "sha256-VYpmh/++8od0fmV5tHGxBiKtWRdnssiL2UXqK+EsEc8=",
      "url": "_framework/Microsoft.CSharp.l4nhbw5tnj.wasm"
    },
    {
      "hash": "sha256-XmI2e4usTUn8mjG/nUVaZbYCmaAS+ClB/WG24O4bc9k=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.qycoarjeru.wasm"
    },
    {
      "hash": "sha256-i4UmIVmRYt9sXQYxprJFXFivAl11xAcf9azr6KH7EOw=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.j66pezmcjo.wasm"
    },
    {
      "hash": "sha256-FaaaOUKTSpAYkiRXlXvtko5FVnHLdZR5AardvxtziDM=",
      "url": "_framework/Microsoft.Extensions.Configuration.pvawjtuhi4.wasm"
    },
    {
      "hash": "sha256-TVc4+FrPoT2ohSnb59Pyb86TNxLYqkdSwT9WshAi6nE=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.j49qkp6o2m.wasm"
    },
    {
      "hash": "sha256-Ta3surCTEATmQUY4SQ/wpAIdyxK5fNnI4bm05ePwAsw=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.vdgbrs4or0.wasm"
    },
    {
      "hash": "sha256-tnMHqb6BpI1Jj9M9WNSAAJzzxHrQgov/aSXbFqc+xzk=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ixsppbtym0.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-zrTQnE9fDoqlKOAMPEfUmbzQkhfhGugTm9xtG+89lJ0=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.qazaeflbok.wasm"
    },
    {
      "hash": "sha256-m2ci2/3UUoSj+LBjDg24wAVdJ7/OshaoahXtPt74ak4=",
      "url": "_framework/Microsoft.Extensions.Logging.dypcmt2k1c.wasm"
    },
    {
      "hash": "sha256-93pAYAommWPUnWivkfPryiWKh9Fd/Lj8WvDOvMfWfE0=",
      "url": "_framework/Microsoft.Extensions.Options.1qi9y3zpi7.wasm"
    },
    {
      "hash": "sha256-zPXs1ZxaGv/gjScqkSbos0m3HyxJufpF3haxdyuT0QA=",
      "url": "_framework/Microsoft.Extensions.Primitives.wdgxpgsqcr.wasm"
    },
    {
      "hash": "sha256-63bzxZLVvNOmTsso6iLrptxGmKBQh2HUIEGtPUrRPeQ=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.lsljofql11.wasm"
    },
    {
      "hash": "sha256-hP00MtFBUzH4VfQmr0vCO/JgXXPBUxu8WZErE/K6sew=",
      "url": "_framework/Microsoft.JSInterop.o187eofblz.wasm"
    },
    {
      "hash": "sha256-tQJipa9Sh2t+CF7nyoe/Ahv03JJDpJB4LBL0wOxbIJA=",
      "url": "_framework/MudBlazor.xhfx6ox00c.wasm"
    },
    {
      "hash": "sha256-A68ZtssOOISrc91Rs8qe/zHZ2envPAmy9bH1JK69WZM=",
      "url": "_framework/NBitcoin.Secp256k1.lim4q7fp0a.wasm"
    },
    {
      "hash": "sha256-puDBip4MxrlGcvm8izPD43x9lAwxmsDgO/AEjFfacNw=",
      "url": "_framework/Nethereum.ABI.6gqr2w64vl.wasm"
    },
    {
      "hash": "sha256-IkTEok3D+n7Ru0s6KU9zj7WD01hOID7jA0w6j6PRbZc=",
      "url": "_framework/Nethereum.Accounts.m6nqc6mocq.wasm"
    },
    {
      "hash": "sha256-OR5Jh/HvR0F6dbJjRcV44KavJU4YLkhOVbB1thn4jpI=",
      "url": "_framework/Nethereum.Blazor.1ij27q8nv4.wasm"
    },
    {
      "hash": "sha256-fAo3jbWg4kXX2rJRKIU2MiIpYw3AuoKroo7cwb+n2Gc=",
      "url": "_framework/Nethereum.BlockchainProcessing.w1g9858u0n.wasm"
    },
    {
      "hash": "sha256-Y3a1aHzFkIdX0xAo7qvcal1FLGe5dvx8ekp7p6P6J/8=",
      "url": "_framework/Nethereum.Contracts.77mw6qtkap.wasm"
    },
    {
      "hash": "sha256-x6uYxrLTRAZlSdMSlRHkE4wemHLc3yD7TO8s0MN8s7I=",
      "url": "_framework/Nethereum.DataServices.3hydku3vow.wasm"
    },
    {
      "hash": "sha256-oYYSct3DNVJcDcQw8s7O7acOG2jUSa2OCSIhGka0QlY=",
      "url": "_framework/Nethereum.EIP6963WalletInterop.honj8knha3.wasm"
    },
    {
      "hash": "sha256-21UulgIOiCm6aADgyT0a+AO5JPZKpj/tJ5PYC45QzA4=",
      "url": "_framework/Nethereum.GnosisSafe.pze5rpdk3r.wasm"
    },
    {
      "hash": "sha256-cSmegCiSo89ZPUKBcLxGhToxQ29HFIqBmJ7hI0thS5A=",
      "url": "_framework/Nethereum.GnosisValidator.53g0srzv0y.wasm"
    },
    {
      "hash": "sha256-tWlBSd/3v+kjWO7P9avXgyeY5rcLLKNhCb8FECg/vTY=",
      "url": "_framework/Nethereum.Hex.x1n0tmm1ei.wasm"
    },
    {
      "hash": "sha256-SA6/hs+2Vxo5ZAwo78UhQd1yTJ0y9Th76bNk0S6ac/M=",
      "url": "_framework/Nethereum.JsonRpc.Client.gme94qbqxd.wasm"
    },
    {
      "hash": "sha256-DwOzwZQcuvRzaZRgwHknGztqz21L7s/JGfaY1HApnVA=",
      "url": "_framework/Nethereum.JsonRpc.RpcClient.7yse556711.wasm"
    },
    {
      "hash": "sha256-313zoTiZfXk7dT0dxfC9/EurLrb4dbIVf+w/ptS7PAo=",
      "url": "_framework/Nethereum.KeyStore.vs175xhs8e.wasm"
    },
    {
      "hash": "sha256-VOgRVLe6l04tlK6n3ttPXmNo/Ll+mItMQF5el5B4yKc=",
      "url": "_framework/Nethereum.Merkle.Patricia.4of4wszafh.wasm"
    },
    {
      "hash": "sha256-aHWM5wohHa9t56xuHjj2iLs3jF8h0bZKIf5kNFB+sUs=",
      "url": "_framework/Nethereum.Metamask.06pkhy0hqp.wasm"
    },
    {
      "hash": "sha256-zSqxKjn41AOsO4HAkG+/8IW+DdDZ22WhATTs9hXFX2A=",
      "url": "_framework/Nethereum.Model.vptvhr3om7.wasm"
    },
    {
      "hash": "sha256-93iyp7VTwLOvj9SjqStplmkL2DOa765uHuSjKzDm6Zs=",
      "url": "_framework/Nethereum.RLP.llg46pdzcx.wasm"
    },
    {
      "hash": "sha256-HwTjESh4OcgW5fQa91t9/Mz6vN1lMGerjP4nJ0cW+I8=",
      "url": "_framework/Nethereum.RPC.jvb43vjohp.wasm"
    },
    {
      "hash": "sha256-KJoRlKxy6erv4czRX17OFD79hAFkw9SoUzVCM8zI08k=",
      "url": "_framework/Nethereum.Signer.EIP712.ok7e0mzkmu.wasm"
    },
    {
      "hash": "sha256-5qagMMpjq1BmDGcp8ukWTNKVy6ctAGdJpzGeE/ENOnY=",
      "url": "_framework/Nethereum.Signer.yp0hx206km.wasm"
    },
    {
      "hash": "sha256-mGZ2vgTAiDMh8pgaTAVApDuWvqSsDk7LxczDPy3i99M=",
      "url": "_framework/Nethereum.Siwe.Core.o8itpj4pui.wasm"
    },
    {
      "hash": "sha256-r15kPy19RdvcSOpZQWot3dDDq9yEztK1LELWi8mjwto=",
      "url": "_framework/Nethereum.Siwe.p23znwrc7i.wasm"
    },
    {
      "hash": "sha256-9E0sAIrklD/lvhNDpyAQ0CwbAGMNFI89TLxrScJBAc4=",
      "url": "_framework/Nethereum.UI.coiesg844f.wasm"
    },
    {
      "hash": "sha256-xs+ch74SLsDXdjsbUkKl5Hjf3W4FXE766QDJWoo4+6s=",
      "url": "_framework/Nethereum.Util.6xt7ds0iyd.wasm"
    },
    {
      "hash": "sha256-H0NbOZQHW2X2xeyvKpUNYZmnPms/71sGcStoQiSLa5M=",
      "url": "_framework/Nethereum.Util.Rest.tp8ze2l1pb.wasm"
    },
    {
      "hash": "sha256-M76Owz0l8LikRx1IazYTt8r2pI0Rlioew9ArExGNbMU=",
      "url": "_framework/Nethereum.Web3.951cx89tlz.wasm"
    },
    {
      "hash": "sha256-Xpm0r0rXv22HXKAg/U0UjDqng/kTiYSPNONjhRP6sYE=",
      "url": "_framework/Newtonsoft.Json.mvfxwucme5.wasm"
    },
    {
      "hash": "sha256-oaUyoVo2a89AwFRLViIDIdBnhpi17mAo03uxs1QLd2g=",
      "url": "_framework/Serilog.Sinks.BrowserConsole.x47anjwz3v.wasm"
    },
    {
      "hash": "sha256-r6airxfnrqh+arB9qDCkZ5CHaJ+f4jjO2tWtyK463OU=",
      "url": "_framework/Serilog.n6wz1e4hol.wasm"
    },
    {
      "hash": "sha256-Psz5YRlGSmUz9FCKZzqF8JLVVKqw3vGPKRtC+CPyqMQ=",
      "url": "_framework/System.Collections.Concurrent.ucveav9yl5.wasm"
    },
    {
      "hash": "sha256-h2NI6E0ruOFF+L6/qywPJKm9RvbSPWaaMh2P6ZhHGoU=",
      "url": "_framework/System.Collections.Immutable.ns84iz2moh.wasm"
    },
    {
      "hash": "sha256-RnFDgR1ivQNPhqotX0L13hu3d8tHb6zwUmaZvs68J9A=",
      "url": "_framework/System.Collections.NonGeneric.uml39a9tnh.wasm"
    },
    {
      "hash": "sha256-FXma7T6ILqb51i6aiQjpZTjjeynuySORC1jy6I6sQrA=",
      "url": "_framework/System.Collections.Specialized.rkgoxfc4xi.wasm"
    },
    {
      "hash": "sha256-Lj4jkkmUvu1Z0/DM6ON1x017g7EEemZu5wlZgWzUXWI=",
      "url": "_framework/System.Collections.uo7h9pt64a.wasm"
    },
    {
      "hash": "sha256-VM0X1x0/dOcEt723d1VehW5bUSy5OctwN1Ey+teT4N0=",
      "url": "_framework/System.ComponentModel.Annotations.g1ai6tngm6.wasm"
    },
    {
      "hash": "sha256-GvbYCxswCALDJLRFRcF8Y8CSXXB0TmvfUo4GLV1cn4Y=",
      "url": "_framework/System.ComponentModel.Primitives.qntz1u3a1q.wasm"
    },
    {
      "hash": "sha256-oa9OOrIhQEtbP4mgO4LUU8ZDpEWy1Ft9SZdT2uhIfU0=",
      "url": "_framework/System.ComponentModel.TypeConverter.pi0cmj2sfj.wasm"
    },
    {
      "hash": "sha256-4OeCSQDmifJ2n9IkYtCOhmXb5hb+BPnwQgu9fkz8O/E=",
      "url": "_framework/System.ComponentModel.kji4l3l9h2.wasm"
    },
    {
      "hash": "sha256-pnkRB4kISVrJXUnv3Hobi7oZVOsZb3eX+6jvk1JrTeg=",
      "url": "_framework/System.Console.uv2vear2g1.wasm"
    },
    {
      "hash": "sha256-q/WKHh4xGZXraLLT3T5Q0nUCAB9Dzv64UX+y7S2RYYg=",
      "url": "_framework/System.Data.Common.lsl8ebtl3o.wasm"
    },
    {
      "hash": "sha256-mPXh53MMYsZTp+L7rAZoMo6EKUtuxL5dxuVfdNwpmMs=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.crwz9broo6.wasm"
    },
    {
      "hash": "sha256-G0J2QtcpJI9vDwUGQjd66n7KZWHkuCasynCtT309lf4=",
      "url": "_framework/System.Diagnostics.TraceSource.713z8c591d.wasm"
    },
    {
      "hash": "sha256-zcqU4bLpKQ2pq4uHcy/xso1tunN7P/fStG6uOZdOlqY=",
      "url": "_framework/System.Drawing.30nntpi0qg.wasm"
    },
    {
      "hash": "sha256-h8ZNutHqn/8JqJvvbT01Bngf6WTwT3oSmeADZZVUsqU=",
      "url": "_framework/System.Drawing.Primitives.vim6bhkozh.wasm"
    },
    {
      "hash": "sha256-MA1NvP4k+njD0T5l9K1w+f3UkRpHdmKh/pbz0fD6JSM=",
      "url": "_framework/System.IO.Compression.wk6ydo9iih.wasm"
    },
    {
      "hash": "sha256-6MYwnV9zbgSpghQzXNODE4VpxPOLL+V+2zb/U/mXMDI=",
      "url": "_framework/System.IO.Pipelines.4dovop59ck.wasm"
    },
    {
      "hash": "sha256-bpxZAIwYJ93BME8A1O9vZgFAFnMkwt2nKWX+yQDN+OM=",
      "url": "_framework/System.Linq.Expressions.yss3foa17y.wasm"
    },
    {
      "hash": "sha256-iV66Y7KbL4oVlodTtucXSNvHYbD7SZQBKZSVigZlRCk=",
      "url": "_framework/System.Linq.tf97n3l2nm.wasm"
    },
    {
      "hash": "sha256-g8iW1rZwS93KDSB6XvP7eUjrx/T4Ky6VS5F/z8wCFYM=",
      "url": "_framework/System.Memory.5ybwjkvi7n.wasm"
    },
    {
      "hash": "sha256-fMfo/jBFsul0VpV1fiaTSqTW2D7y5tUi5qnPFooRY8I=",
      "url": "_framework/System.Net.Http.Json.4ewmujzpq0.wasm"
    },
    {
      "hash": "sha256-AqWD08SiRvo0IV+M/Ge7drTGX0T1Mp8QdkvFX2id0YM=",
      "url": "_framework/System.Net.Http.u5r2728i8u.wasm"
    },
    {
      "hash": "sha256-jYeeN4jmtlFhSerx4kVroAHjVqTqiP3lwbrwHmhDc94=",
      "url": "_framework/System.Net.Primitives.xj8tn04st9.wasm"
    },
    {
      "hash": "sha256-iJv2hzXbgzKRJg+n/sYNZh3I5A9H/HFRICUrDAdU0wY=",
      "url": "_framework/System.Numerics.Vectors.c7jxhlq3co.wasm"
    },
    {
      "hash": "sha256-IxpImvkOb0eJ103/NXUOOnFcFhBnODXBdVHPAIxirKk=",
      "url": "_framework/System.ObjectModel.5e6m8tsfji.wasm"
    },
    {
      "hash": "sha256-QbKQUqcm5RRUbcCHwjYLzNosJ7Xu4gL9VehnqGIF8OA=",
      "url": "_framework/System.Private.CoreLib.hw7pme7mnj.wasm"
    },
    {
      "hash": "sha256-GTa8Z0WTIPTpiXiSm550cMOqsEM1Ibbx9N99ghMiy/w=",
      "url": "_framework/System.Private.Uri.vykbn5yvfk.wasm"
    },
    {
      "hash": "sha256-0Uz8SkbFBuRrPol8T0N3tSzFCNAy0bGfxGcI1DLFwYc=",
      "url": "_framework/System.Private.Xml.Linq.pu02oh6qmr.wasm"
    },
    {
      "hash": "sha256-P1OFtHJu/QwIckEd06tUF7wuuRu8HWCTRmBYv7xZ9Pg=",
      "url": "_framework/System.Private.Xml.bdm8kf0op4.wasm"
    },
    {
      "hash": "sha256-MWGTspxDfuUUhTcW/8bFDYcoRfdfZ0s1kWmafKdMkCo=",
      "url": "_framework/System.Runtime.CompilerServices.Unsafe.dxs7f10vtr.wasm"
    },
    {
      "hash": "sha256-Cjdb0G7x7YHp1aN8K34JIjyB6iQIEsmMfoZJJ71ZuOw=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.mwa725m7o8.wasm"
    },
    {
      "hash": "sha256-PbP5WnBVyIZcfFsBUby2P8wX3cfkviCGavlpzSb4BTg=",
      "url": "_framework/System.Runtime.InteropServices.t8ouds85x7.wasm"
    },
    {
      "hash": "sha256-SN3NL9aHFahe/9QEPtjrkr66mmCEhlZjunoXZ58sznc=",
      "url": "_framework/System.Runtime.Intrinsics.snvgl1gwob.wasm"
    },
    {
      "hash": "sha256-/9GYXKpEh18t+DK7Rz3bvWNWMOAn0DVgkM16mLPm0s8=",
      "url": "_framework/System.Runtime.Numerics.3rrqvd3rf9.wasm"
    },
    {
      "hash": "sha256-NSChJgbB8uvYWi5RhEtE7XHCn9Ozt1zdcHHM6gkrypY=",
      "url": "_framework/System.Runtime.Serialization.Formatters.v73ah8ugzd.wasm"
    },
    {
      "hash": "sha256-NCjo6tWHGKgDPhjK3qJr8Y8Xa48hIZAD+6Gm49bogGY=",
      "url": "_framework/System.Runtime.Serialization.Primitives.ce7buglje3.wasm"
    },
    {
      "hash": "sha256-FTLFfa8taSHVyZ96Y2ppCoNmmDrTp9RB/cFxpoWErA4=",
      "url": "_framework/System.Runtime.ffcsgovpy9.wasm"
    },
    {
      "hash": "sha256-tlsYaxaqJoUHAX2wrAW6GmHhZCiC/gDNLnyBWeQri4Q=",
      "url": "_framework/System.Security.Claims.ipuh6ocvwx.wasm"
    },
    {
      "hash": "sha256-AOxIYrDJ/B5WynhVERReRl7du0xDbPAKGev34p1fDKk=",
      "url": "_framework/System.Security.Cryptography.Algorithms.w411oavva8.wasm"
    },
    {
      "hash": "sha256-ush7POAbfXDm+cnTFPMs5ET2YHAPiA249IKVglSlTsI=",
      "url": "_framework/System.Security.Cryptography.Csp.aj5xlyq445.wasm"
    },
    {
      "hash": "sha256-+LOaMLGTdDD8Cf7w5HNWb/9k8bTDAE8MLDUrortg8YU=",
      "url": "_framework/System.Security.Cryptography.Encoding.o85ixwi0nk.wasm"
    },
    {
      "hash": "sha256-us4na4hDwzVQ7MVMkKr7K90+fsliPIQvsJR91RU2PrE=",
      "url": "_framework/System.Security.Cryptography.Primitives.mho34j0udr.wasm"
    },
    {
      "hash": "sha256-EywSQYU58H6AoTZrY98PqgM/siOa9nd8jM6aLft47/I=",
      "url": "_framework/System.Security.Cryptography.X509Certificates.5iy5afjiv3.wasm"
    },
    {
      "hash": "sha256-13v2XPQndMX1ju9MUMRVQJwJDoWAn9tSAZ5YqbjeLKk=",
      "url": "_framework/System.Security.Cryptography.tjy5y9epbr.wasm"
    },
    {
      "hash": "sha256-KqqWRjKnEB6AfDVf3rm0/MCd7SXbSGKyKpcY/+zEjSA=",
      "url": "_framework/System.Text.Encodings.Web.6kgc70ln9c.wasm"
    },
    {
      "hash": "sha256-phdLsffOJi1UWT7h5HoPiNdJ1AKy/MwwII0uktORngg=",
      "url": "_framework/System.Text.Json.2hc2ckpetl.wasm"
    },
    {
      "hash": "sha256-5vO/YtvVPJzQof7uqxqVK2vaHoBsbT5G1L1OoaBfJ90=",
      "url": "_framework/System.Text.RegularExpressions.ufm65073jh.wasm"
    },
    {
      "hash": "sha256-57YhdEvwDduOGH5zslHwTn1Tpa3pleIg5fykcky5sk0=",
      "url": "_framework/System.Threading.p08q2zr5e6.wasm"
    },
    {
      "hash": "sha256-R9FktnaduRAvMaZfcRZAXAs4UUQFRWQ+IzNgO/1vj8I=",
      "url": "_framework/System.Xml.Linq.no17d80mwx.wasm"
    },
    {
      "hash": "sha256-JTFuCK158shXIWK3NjdzwK5OZag1jcRJzsH8H5Gd6OA=",
      "url": "_framework/System.pndwwxah3a.wasm"
    },
    {
      "hash": "sha256-u1rQYDoXbVgf9OlYtuKS3r807lPnc4Ehclc235Ap80c=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-lIFBSyH5fOmCyz9NzfVceXU09qRLS0mn0JZG0tuYWBo=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-ygKUaNkC7fvq39upIsSP+hAUOpPWp7aHUomBhhShKrw=",
      "url": "_framework/dotnet.native.2x5h1t5d9h.js"
    },
    {
      "hash": "sha256-gNfrMb16+ylnKAGwskLNZATU3BHNo3eHUUAQFwGUmdc=",
      "url": "_framework/dotnet.native.sttu5w8zqj.wasm"
    },
    {
      "hash": "sha256-gypqZnsxxUh4y4EJmawvOCaX4hoTaesVGwIgWXwZcNw=",
      "url": "_framework/dotnet.runtime.rubq0v1yiy.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-TD8Z+F6j2ZWU5vuWrSiW4I+ZtLuxJePcFYxs0SrpFMc=",
      "url": "_framework/netstandard.on6wfiax7r.wasm"
    },
    {
      "hash": "sha256-+A9GJSL1F7E2tMCpF5MhfSLW2Gd35PbafP4B4Z7MEcE=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-yis2dNdJ6e9R472mcuwUOsxBPCQX3snSMmHAL3zu2D8=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-77ubOEwi8yWEd/xB/e01F5T/ljzYqME0YZnuHrA6j9A=",
      "url": "index.html"
    },
    {
      "hash": "sha256-VSQRX1zufPPfljeh63jtX4Vvpz7IiZ3mWL3FRcPG7gM=",
      "url": "manifest.webmanifest"
    }
  ]
};
